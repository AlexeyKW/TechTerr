# tech_terr > 2024-03-21 10:57pm
https://universe.roboflow.com/mappoints/tech_terr

Provided by a Roboflow user
License: CC BY 4.0

